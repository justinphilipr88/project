// +build !windows

package lfsapi

var netrcBasename = ".netrc"
