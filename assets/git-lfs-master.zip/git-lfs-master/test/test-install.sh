#!/usr/bin/env bash

. "test/testlib.sh"

begin_test "install again"
(
  set -e

  smudge="$(git config filter.lfs.smudge)"
  clean="$(git config filter.lfs.clean)"
  filter="$(git config filter.lfs.process)"

  printf "$smudge" | grep "git-lfs smudge"
  printf "$clean" | grep "git-lfs clean"
  printf "$filter" | grep "git-lfs filter-process"

  git lfs install

  [ "$smudge" = "$(git config filter.lfs.smudge)" ]
  [ "$clean" = "$(git config filter.lfs.clean)" ]
  [ "$filter" = "$(git config filter.lfs.process)" ]
)
end_test

begin_test "install with old (non-upgradeable) settings"
(
  set -e

  git config --global filter.lfs.smudge "git-lfs smudge --something %f"
  git config --global filter.lfs.clean "git-lfs clean --something %f"

  set +e
  git lfs install 2> install.log
  res=$?
  set -e

  [ "$res" = 2 ]

  cat install.log
  grep -E "(clean|smudge) attribute should be" install.log
  [ `grep -c "(MISSING)" install.log` = "0" ]

  [ "git-lfs smudge --something %f" = "$(git config --global filter.lfs.smudge)" ]
  [ "git-lfs clean --something %f" = "$(git config --global filter.lfs.clean)" ]

  git lfs install --force
  [ "git-lfs smudge -- %f" = "$(git config --global filter.lfs.smudge)" ]
  [ "git-lfs clean -- %f" = "$(git config --global filter.lfs.clean)" ]
)
end_test

begin_test "install with upgradeable settings"
(
  set -e

  git config --global filter.lfs.smudge "git-lfs smudge %f"
  git config --global filter.lfs.clean "git-lfs clean %f"

  # should not need force, should upgrade this old style
  git lfs install
  [ "git-lfs smudge -- %f" = "$(git config --global filter.lfs.smudge)" ]
  [ "git-lfs clean -- %f" = "$(git config --global filter.lfs.clean)" ]
  [ "git-lfs filter-process" = "$(git config --global filter.lfs.process)" ]
)
end_test

begin_test "install updates repo hooks"
(
  set -e

  mkdir install-repo-hooks
  cd install-repo-hooks
  git init

  pre_push_hook="#!/bin/sh
command -v git-lfs >/dev/null 2>&1 || { echo >&2 \"\\nThis repository is configured for Git LFS but 'git-lfs' was not found on your path. If you no longer wish to use Git LFS, remove this hook by deleting .git/hooks/pre-push.\\n\"; exit 2; }
git lfs pre-push \"\$@\""

  post_checkout_hook="#!/bin/sh
command -v git-lfs >/dev/null 2>&1 || { echo >&2 \"\\nThis repository is configured for Git LFS but 'git-lfs' was not found on your path. If you no longer wish to use Git LFS, remove this hook by deleting .git/hooks/post-checkout.\\n\"; exit 2; }
git lfs post-checkout \"\$@\""

  post_commit_hook="#!/bin/sh
command -v git-lfs >/dev/null 2>&1 || { echo >&2 \"\\nThis repository is configured for Git LFS but 'git-lfs' was not found on your path. If you no longer wish to use Git LFS, remove this hook by deleting .git/hooks/post-commit.\\n\"; exit 2; }
git lfs post-commit \"\$@\""

  post_merge_hook="#!/bin/sh
command -v git-lfs >/dev/null 2>&1 || { echo >&2 \"\\nThis repository is configured for Git LFS but 'git-lfs' was not found on your path. If you no longer wish to use Git LFS, remove this hook by deleting .git/hooks/post-merge.\\n\"; exit 2; }
git lfs post-merge \"\$@\""

  [ "Updated git hooks.
Git LFS initialized." = "$(git lfs install)" ]
  [ "$pre_push_hook" = "$(cat .git/hooks/pre-push)" ]
  [ "$post_checkout_hook" = "$(cat .git/hooks/post-checkout)" ]
  [ "$post_commit_hook" = "$(cat .git/hooks/post-commit)" ]
  [ "$post_merge_hook" = "$(cat .git/hooks/post-merge)" ]

  # replace old hook
  # more-comprehensive hook update tests are in test-update.sh
  echo "#!/bin/sh
git lfs push --stdin \$*" > .git/hooks/pre-push
  [ "Updated git hooks.
Git LFS initialized." = "$(git lfs install)" ]
  [ "$pre_push_hook" = "$(cat .git/hooks/pre-push)" ]

  # don't replace unexpected hook
  expected="Hook already exists: pre-push

test

To resolve this, either:
  1: run \`git lfs update --manual\` for instructions on how to merge hooks.
  2: run \`git lfs update --force\` to overwrite your hook."

  echo "test" > .git/hooks/pre-push
  echo "test" > .git/hooks/post-checkout
  echo "test" > .git/hooks/post-commit
  echo "test" > .git/hooks/post-merge
  [ "test" = "$(cat .git/hooks/pre-push)" ]
  [ "$expected" = "$(git lfs install 2>&1)" ]
  [ "test" = "$(cat .git/hooks/pre-push)" ]
  [ "test" = "$(cat .git/hooks/post-checkout)" ]
  [ "test" = "$(cat .git/hooks/post-commit)" ]
  [ "test" = "$(cat .git/hooks/post-merge)" ]

  # Make sure returns non-zero
  set +e
  git lfs install
  if [ $? -eq 0 ]
  then
    exit 1
  fi
  set -e

  # force replace unexpected hook
  [ "Updated git hooks.
Git LFS initialized." = "$(git lfs install --force)" ]
  [ "$pre_push_hook" = "$(cat .git/hooks/pre-push)" ]
  [ "$post_checkout_hook" = "$(cat .git/hooks/post-checkout)" ]
  [ "$post_commit_hook" = "$(cat .git/hooks/post-commit)" ]
  [ "$post_merge_hook" = "$(cat .git/hooks/post-merge)" ]

  has_test_dir || exit 0

  echo "test with bare repository"
  cd ..
  git clone --mirror install-repo-hooks bare-install-repo-hooks
  cd bare-install-repo-hooks
  git lfs env
  git lfs install
  ls -al hooks
  [ "$pre_push_hook" = "$(cat hooks/pre-push)" ]
)
end_test

begin_test "install outside repository directory"
(
  set -e
  if [ -d "hooks" ]; then
    ls -al
    echo "hooks dir exists"
    exit 1
  fi

  git lfs install 2>&1 > check.log

  if [ -d "hooks" ]; then
    ls -al
    echo "hooks dir exists"
    exit 1
  fi

  cat check.log

  # doesn't print this because being in a git repo is not necessary for install
  [ "$(grep -c "Not in a git repository" check.log)" = "0" ]
)
end_test

begin_test "install --skip-smudge"
(
  set -e

  mkdir install-skip-smudge-test
  cd install-skip-smudge-test

  git lfs install
  [ "git-lfs clean -- %f" = "$(git config --global filter.lfs.clean)" ]
  [ "git-lfs smudge -- %f" = "$(git config --global filter.lfs.smudge)" ]
  [ "git-lfs filter-process" = "$(git config --global filter.lfs.process)" ]

  git lfs install --skip-smudge
  [ "git-lfs clean -- %f" = "$(git config --global filter.lfs.clean)" ]
  [ "git-lfs smudge --skip -- %f" = "$(git config --global filter.lfs.smudge)" ]
  [ "git-lfs filter-process --skip" = "$(git config --global filter.lfs.process)" ]

  git lfs install --force
  [ "git-lfs clean -- %f" = "$(git config --global filter.lfs.clean)" ]
  [ "git-lfs smudge -- %f" = "$(git config --global filter.lfs.smudge)" ]
  [ "git-lfs filter-process" = "$(git config --global filter.lfs.process)" ]

  [ ! -e "lfs" ]
)
end_test

begin_test "install --local"
(
  set -e

  # old values that should be ignored by `install --local`
  git config --global filter.lfs.smudge "git lfs smudge %f"
  git config --global filter.lfs.clean "git lfs clean %f"

  mkdir install-local-repo
  cd install-local-repo
  git init
  git lfs install --local

  [ "git-lfs clean -- %f" = "$(git config filter.lfs.clean)" ]
  [ "git-lfs clean -- %f" = "$(git config --local filter.lfs.clean)" ]
  [ "git lfs clean %f" = "$(git config --global filter.lfs.clean)" ]
  [ "git-lfs filter-process" = "$(git config filter.lfs.process)" ]
  [ "git-lfs filter-process" = "$(git config --local filter.lfs.process)" ]
)
end_test

begin_test "install --local outside repository"
(
  # If run inside the git-lfs source dir this will update its .git/config & cause issues
  if [ "$GIT_LFS_TEST_DIR" == "" ]; then
    echo "Skipping install --local because GIT_LFS_TEST_DIR is not set"
    exit 0
  fi

  set +e

  has_test_dir || exit 0

  git lfs install --local 2> err.log
  res=$?

  [ "Not in a git repository." = "$(cat err.log)" ]
  [ "0" != "$res" ]
)
end_test

begin_test "install in directory without access to .git/lfs"
(
  set -e
  mkdir not-a-repo
  cd not-a-repo
  mkdir .git
  touch .git/lfs
  touch lfs

  git config --global filter.lfs.clean whatevs
  [ "whatevs" = "$(git config filter.lfs.clean)" ]

  git lfs install --force

  [ "git-lfs clean -- %f" = "$(git config filter.lfs.clean)" ]
)
end_test


begin_test "install in repo without changing hooks"
(
  set -e
  git init non-lfs-repo
  cd non-lfs-repo

  git lfs install --skip-repo

  # should not install hooks
  [ ! -f .git/hooks/pre-push ]
  [ ! -f .git/hooks/post-checkout ]
  [ ! -f .git/hooks/post-merge ]
  [ ! -f .git/hooks/post-commit ]

  # filters should still be installed
  [ "git-lfs clean -- %f" = "$(git config filter.lfs.clean)" ]
  [ "git-lfs smudge -- %f" = "$(git config filter.lfs.smudge)" ]
  [ "git-lfs filter-process" = "$(git config filter.lfs.process)" ]
)
end_test
